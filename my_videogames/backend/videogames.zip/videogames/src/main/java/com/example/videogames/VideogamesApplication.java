package com.example.videogames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VideogamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideogamesApplication.class, args);
	}

}
