package com.example.videogames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideogamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
